package es.upm.dit.isst.concierge.model;

import java.io.Serializable;
import java.util.Collection;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Cliente implements Serializable {
	
	 private static final long serialVersionUID = 1L;
	
	@Id 
	private String dni;
	public String room; 
	public String name;
	
	@OneToMany(mappedBy = "advisor", fetch = FetchType.EAGER) 
	private Collection<Peticion> advisedPeticiones;
	
	
	public Cliente() {
		super();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((dni == null) ? 0 : dni.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Cliente other = (Cliente) obj;
		if (dni == null) {
			if (other.dni != null)
				return false;
		} else if (!dni.equals(other.dni))
			return false;
		return true;
	}

	

	@Override
	public String toString() {
		return "Cliente [dni=" + dni + ", room=" + room + ", name=" + name + ", advisedPeticiones=" + advisedPeticiones
				+ "]";
	}
	

	public String getDni() {
		return dni;
	}

	public void setDni(String dni) {
		this.dni = dni;
	}

	public String getRoom() {
		return room;
	}

	public void setRoom(String room) {
		this.room = room;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Collection<Peticion> getAdvisedPeticiones() {
		return advisedPeticiones;
	}

	public void setAdvisedPeticiones(Collection<Peticion> advisedPeticiones) {
		this.advisedPeticiones = advisedPeticiones;
	}

}
