package es.upm.dit.isst.concierge.servlet;

import java.io.IOException;
import java.util.Collection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;

import es.upm.dit.isst.concierge.dao.Cliente3DAOImplementation;
import es.upm.dit.isst.concierge.dao.Peticion3DAOImplementation;
import es.upm.dit.isst.concierge.model.Cliente3;
import es.upm.dit.isst.concierge.model.Peticion3;

/**
 * Servlet implementation class FormCreaPeticion3
 */
@WebServlet("/FormCreaPeticion3")
public class FormCreaPeticion3 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FormCreaPeticion3() {
        super();
        // TODO Auto-generated constructor stub
    }
    @SuppressWarnings("unchecked")
   	@Override
   	protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
   			throws ServletException, IOException {
   		String titulo = req.getParameter("titulo");
   		String mensaje = req.getParameter("mensaje");
   		String dni = req.getParameter("dni");

   			Collection<Cliente3> clientes3 = Cliente3DAOImplementation.getInstancia().readAll();
   			for(Cliente3 p: clientes3) {
   				if(p.getDni().contentEquals(dni)) {
   					Peticion3 peticion = new Peticion3();
   					peticion.setId_peticion(titulo);
   					peticion.setMensaje(mensaje);
   					peticion.setAdvisor3(p);
   					peticion.setEstado(1);
   					
   					JOptionPane.showMessageDialog(null,"Petición pendiente de aceptación");
   					
   					Peticion3DAOImplementation.getInstancia().create(peticion);
   					Collection<Peticion3> lp= Peticion3DAOImplementation.getInstancia().readAll(); 
   					req.getSession().setAttribute("peticiones3", lp);
   					//List<Peticion> pet = new ArrayList<Peticion>();
   					//pet.add (peticion);
   					//pet.addAll((List<Peticion>) req.getAttribute("peticiones"));
   					//req.getSession().setAttribute("peticiones", pet);
   					getServletContext().getRequestDispatcher("/estandar.html").forward(req,resp);
   					
   				
   					
   				}else {
   					//JOptionPane.showMessageDialog(null,"dni incorrecto");
   					getServletContext().getRequestDispatcher("/FormCrearPeticion2.jsp").forward(req,resp);
   				}
   			}
       }
}
