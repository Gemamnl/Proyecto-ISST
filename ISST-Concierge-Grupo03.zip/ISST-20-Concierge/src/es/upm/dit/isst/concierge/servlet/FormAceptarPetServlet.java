package es.upm.dit.isst.concierge.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;

import es.upm.dit.isst.concierge.dao.EmpleadoDAOImplementation;
import es.upm.dit.isst.concierge.dao.PeticionDAOImplementation;
import es.upm.dit.isst.concierge.model.Empleado;
import es.upm.dit.isst.concierge.model.Peticion;

/**
 * Servlet implementation class FormAceptarPetServlet
 */
@WebServlet("/FormAceptarPetServlet")
public class FormAceptarPetServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FormAceptarPetServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Peticion pet = PeticionDAOImplementation.getInstancia().read(req.getParameter("idpeticion"));
		pet.setEstado(2);
		PeticionDAOImplementation.getInstancia().update(pet);
		JOptionPane.showMessageDialog(null,"Petici�n Aceptada");
		req.getSession().setAttribute("peticiones", PeticionDAOImplementation.getInstancia().readAll());
		getServletContext().getRequestDispatcher("/Empleados2.jsp").forward(req,resp);
	}

}
