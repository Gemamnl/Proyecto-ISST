package es.upm.dit.isst.concierge.model;

import java.io.Serializable;
import java.util.Collection;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Cliente2 implements Serializable {
	
	 private static final long serialVersionUID = 1L;
	
	@Id 
	private String dni;
	public String room; 
	public String name;
	
	@OneToMany(mappedBy = "advisor", fetch = FetchType.EAGER) 
	private Collection<Peticion2> advisedPeticiones2;
	
	
	public Cliente2() {
		super();
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((dni == null) ? 0 : dni.hashCode());
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Cliente2 other = (Cliente2) obj;
		if (dni == null) {
			if (other.dni != null)
				return false;
		} else if (!dni.equals(other.dni))
			return false;
		return true;
	}


	@Override
	public String toString() {
		return "Cliente2 [dni=" + dni + ", room=" + room + ", name=" + name + ", advisedPeticiones2=" + advisedPeticiones2
				+ "]";
	}


	public String getDni() {
		return dni;
	}


	public void setDni(String dni) {
		this.dni = dni;
	}


	public String getRoom() {
		return room;
	}


	public void setRoom(String room) {
		this.room = room;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public Collection<Peticion2> getAdvisedPeticiones() {
		return advisedPeticiones2;
	}


	public void setAdvisedPeticiones(Collection<Peticion2> advisedPeticiones2) {
		this.advisedPeticiones2 = advisedPeticiones2;
	}


}
