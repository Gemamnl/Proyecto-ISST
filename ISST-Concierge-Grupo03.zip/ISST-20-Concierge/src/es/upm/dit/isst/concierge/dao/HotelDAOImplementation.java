package es.upm.dit.isst.concierge.dao;

import java.util.Collection;
import java.util.List;

import org.hibernate.Session;

import es.upm.dit.isst.concierge.model.Hotel;

public class HotelDAOImplementation implements HotelDAO {
	private static HotelDAOImplementation instancia = null;
	  private HotelDAOImplementation() {
	  }

	  public static HotelDAOImplementation getInstancia() {
	    if( null == instancia ) 
	      instancia = new HotelDAOImplementation();
	    return instancia;
	  }
	  
	  @Override
	  public Hotel read (String name) {
	    Session session = SessionFactoryService.get().openSession();
	    session.beginTransaction();
	    Hotel p=session.get(Hotel.class, name);
	    session.getTransaction().commit();
	    session.close();
	    return p;
	  }
	  
	  @Override
	  public void create (Hotel hotel) {
	    Session session = SessionFactoryService.get().openSession();
	    session.beginTransaction();
	    session.save(hotel);
	    session.getTransaction().commit();
	    session.close();
	  }
	  
	  @Override
	  public void update(Hotel hotel) {
	    Session session = SessionFactoryService.get().openSession();
	    session.beginTransaction();
	    session.saveOrUpdate(session);
	    session.getTransaction().commit();
	    session.close();
	  }
	  
	  @Override
	  public void delete(Hotel hotel) {
	    Session session = SessionFactoryService.get().openSession();
	    session.beginTransaction();
	    session.delete(hotel);
	    session.getTransaction().commit();
	    session.close();
	  }
	  
	  @SuppressWarnings("unchecked")
	  @Override
	  public Collection<Hotel>readAll() {
	    Session session = SessionFactoryService.get().openSession();
	    session.beginTransaction();
	    List<Hotel>hoteles=session.createQuery("from Hotel").list();
	    session.getTransaction().commit();
	    session.close();
	    return hoteles;
	  }

}
