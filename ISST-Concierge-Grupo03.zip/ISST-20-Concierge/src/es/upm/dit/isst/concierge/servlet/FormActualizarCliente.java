package es.upm.dit.isst.concierge.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.annotations.common.util.impl.Log;

import es.upm.dit.isst.concierge.dao.*;
import es.upm.dit.isst.concierge.model.*;


@SuppressWarnings("unused")
@WebServlet("/FormActualizarCliente")
public class FormActualizarCliente extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
						
		String name = req.getParameter("name");
		String dni = req.getParameter("dni");
		String room = req.getParameter("room");
		
		
		Cliente cliente = new Cliente();
		cliente.setName(name);
		cliente.setDni(dni);
		cliente.setRoom(room);
		
		
		ClienteDAOImplementation.getInstancia().create(cliente);
		Collection<Cliente> lp =ClienteDAOImplementation.getInstancia().readAll();
		req.getSession().setAttribute("clientes", lp);
		getServletContext().getRequestDispatcher("/ActualizarPerfil.jsp").forward(req,resp);
		
		
					
		getServletContext().getRequestDispatcher("/ActualizarPerfil.jsp").forward(req,resp);
	}


}
