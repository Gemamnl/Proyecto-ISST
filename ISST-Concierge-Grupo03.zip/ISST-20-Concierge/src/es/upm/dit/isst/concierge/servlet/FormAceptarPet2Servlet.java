package es.upm.dit.isst.concierge.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;

import es.upm.dit.isst.concierge.dao.Peticion2DAOImplementation;
import es.upm.dit.isst.concierge.model.Peticion2;

/**
 * Servlet implementation class FormAceptarPet2Servlet
 */
@WebServlet("/FormAceptarPet2Servlet")
public class FormAceptarPet2Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FormAceptarPet2Servlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Peticion2 pet = Peticion2DAOImplementation.getInstancia().read(req.getParameter("idpeticion"));
		pet.setEstado(2);
		Peticion2DAOImplementation.getInstancia().update(pet);
		JOptionPane.showMessageDialog(null,"Petici�n Aceptada");
		req.getSession().setAttribute("peticiones2", Peticion2DAOImplementation.getInstancia().readAll());
		getServletContext().getRequestDispatcher("/Empleados2.jsp").forward(req,resp);
	}
}
