package es.upm.dit.isst.concierge.dao;

import java.util.Collection;
import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;

import es.upm.dit.isst.concierge.model.Cliente3;

public class Cliente3DAOImplementation implements Cliente3DAO {
	private static Cliente3DAOImplementation instancia = null;
	  private Cliente3DAOImplementation() {
	  }

	  public static Cliente3DAOImplementation getInstancia() {
	    if( null == instancia ) 
	      instancia = new Cliente3DAOImplementation();
	    return instancia;
	  }
	  
	  @Override
	  public Cliente3 read (String name) {
	    Session session = SessionFactoryService.get().openSession();
	    session.beginTransaction();
	    Cliente3 p=session.get(Cliente3.class, name);
	    session.getTransaction().commit();
	    session.close();
	    return p;
	  }
	  
	  @Override
	  public void create (Cliente3 cliente) {
	    Session session = SessionFactoryService.get().openSession();
	    session.beginTransaction();
	    session.save(cliente);
	    session.getTransaction().commit();
	    session.close();
	  }
	  
	  @Override
	  public void update(Cliente3 cliente) {
	    Session session = SessionFactoryService.get().openSession();
	    session.beginTransaction();
	    session.update(session);
	    session.getTransaction().commit();
	    session.close();
	  }
	  
	  @Override
	  public void delete(Cliente3 cliente) {
	    Session session = SessionFactoryService.get().openSession();
	    session.beginTransaction();
	    session.delete(cliente);
	    session.getTransaction().commit();
	    session.close();
	  }
	  
	  @SuppressWarnings("unchecked")
	  @Override
	  public Collection<Cliente3>readAll() {
	    Session session = SessionFactoryService.get().openSession();
	    session.beginTransaction();
	    List<Cliente3>clientes3= session.createQuery("from Cliente3").list();
	    session.getTransaction().commit();
	    session.close();
	    return clientes3;
	  }
	  
	  @SuppressWarnings("unchecked")
	  @Override
	  public Cliente3 login(String dni,String room) {
	    Session session = SessionFactoryService.get().openSession();
	    session.beginTransaction();
	    Cliente3 p=null;
	    Query q=session.createQuery("select p from Cliente3 p where p.dni= :dni and p.room= :room");
	    q.setParameter("dni", dni);
	    q.setParameter("room", room);
	    List<Cliente3> profs=q.getResultList();
	    if (profs.size()>0)
	    	p=(Cliente3)(q.getResultList().get(0));
	    session.getTransaction().commit();
	    session.close();
	    return p;
	  }

	  


}
