package es.upm.dit.isst.concierge.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import es.upm.dit.isst.concierge.dao.ClienteDAOImplementation;
import es.upm.dit.isst.concierge.dao.HotelDAOImplementation;
import es.upm.dit.isst.concierge.model.Cliente;
import es.upm.dit.isst.concierge.model.Hotel;

/**
 * Servlet implementation class FormCreaHotel
 */
@WebServlet("/FormCreaHotel")
public class FormCreaHotel extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FormCreaHotel() {
        super();
        // TODO Auto-generated constructor stub
    }

    @SuppressWarnings("unchecked")
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
           throws ServletException, IOException {
		String name = req.getParameter("name");
		String dir = req.getParameter("direccion");
		String estrellas = req.getParameter("estrellas");
		
		
		Hotel hotel = new Hotel();
		hotel.setName(name);
		hotel.setDireccion(dir);
		hotel.setEstrellas(estrellas);
		
		
		HotelDAOImplementation.getInstancia().create(hotel);
		Collection<Hotel> lp= HotelDAOImplementation.getInstancia().readAll(); 
		req.getSession().setAttribute("hoteles", lp);
		//List<Hotel> lp = new ArrayList<Hotel>();
		//lp.addAll((List<Hotel>) req.getAttribute("hoteles"));
		//lp.add (hotel);
		//req.getSession().setAttribute("hoteles", lp);
		getServletContext().getRequestDispatcher("/Admin.jsp").forward(req,resp);
	}


}
