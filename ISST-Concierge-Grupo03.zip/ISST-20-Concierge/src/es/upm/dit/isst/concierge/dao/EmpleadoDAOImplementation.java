package es.upm.dit.isst.concierge.dao;

import java.util.Collection;
import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;

import es.upm.dit.isst.concierge.model.Empleado;

public class EmpleadoDAOImplementation implements EmpleadoDAO {
		private static EmpleadoDAOImplementation instancia = null;
		  private EmpleadoDAOImplementation() {
		  }

		  public static EmpleadoDAOImplementation getInstancia() {
		    if( null == instancia ) 
		      instancia = new EmpleadoDAOImplementation();
		    return instancia;
		  }
		  
		  @Override
		  public Empleado read (String name) {
		    Session session = SessionFactoryService.get().openSession();
		    session.beginTransaction();
		    Empleado p=session.get(Empleado.class, name);
		    session.getTransaction().commit();
		    session.close();
		    return p;
		  }
		  
		  @Override
		  public void create (Empleado empleado) {
		    Session session = SessionFactoryService.get().openSession();
		    session.beginTransaction();
		    session.save(empleado);
		    session.getTransaction().commit();
		    session.close();
		  }
		  
		  @Override
		  public void update(Empleado empleado) {
		    Session session = SessionFactoryService.get().openSession();
		    session.beginTransaction();
		    session.saveOrUpdate(session);
		    session.getTransaction().commit();
		    session.close();
		  }
		  
		  @Override
		  public void delete(Empleado empleado) {
		    Session session = SessionFactoryService.get().openSession();
		    session.beginTransaction();
		    session.delete(empleado);
		    session.getTransaction().commit();
		    session.close();
		  }
		  
		  @SuppressWarnings("unchecked")
		  @Override
		  public Collection<Empleado>readAll() {
		    Session session = SessionFactoryService.get().openSession();
		    session.beginTransaction();
		    List<Empleado>empleados=session.createQuery("from Empleado").list();
		    session.getTransaction().commit();
		    session.close();
		    return empleados;
		  }
		  
		  @SuppressWarnings("unchecked")
		  @Override
		  public Empleado login(String dni,String room) {
		    Session session = SessionFactoryService.get().openSession();
		    session.beginTransaction();
		    Empleado p=null;
		    Query q=session.createQuery("select p from Empleado p where p.dni= :dni and p.room= :room");
		    q.setParameter("dni", dni);
		    q.setParameter("room", room);
		    List<Empleado> profs=q.getResultList();
		    if (profs.size()>0)
		    	p=(Empleado)(q.getResultList().get(0));
		    session.getTransaction().commit();
		    session.close();
		    return p;
		  }

}
