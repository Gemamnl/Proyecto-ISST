package es.upm.dit.isst.concierge.dao;

import java.util.Collection;
import java.util.List;

import org.hibernate.Session;

import es.upm.dit.isst.concierge.model.Peticion;

public class PeticionDAOImplementation implements PeticionDAO {
	private static PeticionDAOImplementation instancia = null;
	  private PeticionDAOImplementation() {
	  }

	  public static PeticionDAOImplementation getInstancia() {
	    if( null == instancia ) 
	      instancia = new PeticionDAOImplementation();
	    return instancia;
	  }
	  
	  @Override
	  public Peticion read(String id_peticion) {
	    Session session = SessionFactoryService.get().openSession();
	    session.beginTransaction();
	    Peticion p=session.get(Peticion.class, id_peticion);
	    session.getTransaction().commit();
	    session.close();
	    return p;
	  }
	  
	  @Override
	  public void create (Peticion peticion) {
	    Session session = SessionFactoryService.get().openSession();
	    session.beginTransaction();
	    session.save(peticion);
	    session.getTransaction().commit();
	    session.close();
	  }
	  
	  @Override
	  public void update(Peticion peticion) {
	    Session session = SessionFactoryService.get().openSession();
	    session.beginTransaction();
	    session.saveOrUpdate(peticion);
	    session.getTransaction().commit();
	    session.close();
	  }
	  
	  @Override
	  public void delete(Peticion peticion) {
	    Session session = SessionFactoryService.get().openSession();
	    session.beginTransaction();
	    session.delete(peticion);
	    session.getTransaction().commit();
	    session.close();
	  }
	  
	  @SuppressWarnings("unchecked")
	  @Override
	  public Collection<Peticion> readAll() {
	    Session session = SessionFactoryService.get().openSession();
	    session.beginTransaction();
	    List<Peticion>peticiones=session.createQuery("from Peticion").list();
	    session.getTransaction().commit();
	    session.close();
	    return peticiones;
	  }


}
