package es.upm.dit.isst.concierge.dao;

import java.util.Collection;
import java.util.List;

import es.upm.dit.isst.concierge.model.Peticion3;

public interface Peticion3DAO {
	
	public void create(Peticion3 peticion);
	public Peticion3 read(String id_peticion);
	public void update(Peticion3 peticion);
	public void delete(Peticion3 peticion);
	public Collection<Peticion3> readAll();
	

}
