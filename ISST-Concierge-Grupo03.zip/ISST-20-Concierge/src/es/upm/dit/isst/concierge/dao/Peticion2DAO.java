package es.upm.dit.isst.concierge.dao;

import java.util.Collection;
import java.util.List;

import es.upm.dit.isst.concierge.model.Peticion2;

public interface Peticion2DAO {
	
	public void create(Peticion2 peticion);
	public Peticion2 read(String id_peticion);
	public void update(Peticion2 peticion);
	public void delete(Peticion2 peticion);
	public Collection<Peticion2> readAll();
	

}
