package es.upm.dit.isst.concierge.dao;

import java.util.Collection;
import java.util.List;

import org.hibernate.Session;

import es.upm.dit.isst.concierge.model.Peticion3;

public class Peticion3DAOImplementation implements Peticion3DAO {
	private static Peticion3DAOImplementation instancia = null;
	  private Peticion3DAOImplementation() {
	  }

	  public static Peticion3DAOImplementation getInstancia() {
	    if( null == instancia ) 
	      instancia = new Peticion3DAOImplementation();
	    return instancia;
	  }
	  
	  @Override
	  public Peticion3 read(String id_peticion) {
	    Session session = SessionFactoryService.get().openSession();
	    session.beginTransaction();
	    Peticion3 p=session.get(Peticion3.class, id_peticion);
	    session.getTransaction().commit();
	    session.close();
	    return p;
	  }
	  
	  @Override
	  public void create (Peticion3 peticion) {
	    Session session = SessionFactoryService.get().openSession();
	    session.beginTransaction();
	    session.save(peticion);
	    session.getTransaction().commit();
	    session.close();
	  }
	  
	  @Override
	  public void update(Peticion3 peticion) {
	    Session session = SessionFactoryService.get().openSession();
	    session.beginTransaction();
	    session.saveOrUpdate(peticion);
	    session.getTransaction().commit();
	    session.close();
	  }
	  
	  @Override
	  public void delete(Peticion3 peticion) {
	    Session session = SessionFactoryService.get().openSession();
	    session.beginTransaction();
	    session.delete(peticion);
	    session.getTransaction().commit();
	    session.close();
	  }
	  
	  @SuppressWarnings("unchecked")
	  @Override
	  public Collection<Peticion3> readAll() {
	    Session session = SessionFactoryService.get().openSession();
	    session.beginTransaction();
	    List<Peticion3>peticiones=session.createQuery("from Peticion3").list();
	    session.getTransaction().commit();
	    session.close();
	    return peticiones;
	  }


}
