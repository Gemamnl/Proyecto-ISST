package es.upm.dit.isst.concierge.servlet;

import java.io.IOException;
import java.util.Collection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;

import es.upm.dit.isst.concierge.dao.Cliente2DAOImplementation;
import es.upm.dit.isst.concierge.dao.Peticion2DAOImplementation;
import es.upm.dit.isst.concierge.model.Cliente2;
import es.upm.dit.isst.concierge.model.Peticion2;

/**
 * Servlet implementation class FormCrearPeticion2
 */
@WebServlet("/FormCrearPeticion2")
public class FormCrearPeticion2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FormCrearPeticion2() {
        super();
        // TODO Auto-generated constructor stub
    }

    @SuppressWarnings("unchecked")
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
			throws ServletException, IOException {
		String titulo = req.getParameter("titulo");
		String mensaje = req.getParameter("mensaje");
		String dni = req.getParameter("dni");

			Collection<Cliente2> clientes2 = Cliente2DAOImplementation.getInstancia().readAll();
			for(Cliente2 p: clientes2) {
				if(p.getDni().contentEquals(dni)) {
					Peticion2 peticion = new Peticion2();
					peticion.setId_peticion(titulo);
					peticion.setMensaje(mensaje);
					peticion.setAdvisor2(p);
					peticion.setEstado(1);
					
					JOptionPane.showMessageDialog(null,"Petición pendiente de aceptación");
					
					Peticion2DAOImplementation.getInstancia().create(peticion);
					Collection<Peticion2> lp= Peticion2DAOImplementation.getInstancia().readAll(); 
					req.getSession().setAttribute("peticiones2", lp);
					//List<Peticion> pet = new ArrayList<Peticion>();
					//pet.add (peticion);
					//pet.addAll((List<Peticion>) req.getAttribute("peticiones"));
					//req.getSession().setAttribute("peticiones", pet);
					getServletContext().getRequestDispatcher("/frecuente.html").forward(req,resp);
					
				
					
				}else {
					//JOptionPane.showMessageDialog(null,"dni incorrecto");
					getServletContext().getRequestDispatcher("/FormCrearPeticion2.jsp").forward(req,resp);
				}
			}
    }
			

}
