package es.upm.dit.isst.concierge.dao;

import java.util.Collection;

import es.upm.dit.isst.concierge.model.Cliente2;



public interface Cliente2DAO {

		public void create(Cliente2 cliente);
		public Cliente2 read(String name);
		public void update(Cliente2 cliente);
		public void delete(Cliente2 cliente);
		public Collection<Cliente2> readAll();
		public Cliente2 login(String dni, String room);

}
