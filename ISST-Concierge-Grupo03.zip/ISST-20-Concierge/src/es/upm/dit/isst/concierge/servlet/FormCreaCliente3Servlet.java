package es.upm.dit.isst.concierge.servlet;

import java.io.IOException;
import java.util.Collection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import es.upm.dit.isst.concierge.dao.Cliente3DAOImplementation;
import es.upm.dit.isst.concierge.model.Cliente3;

/**
 * Servlet implementation class FormCreaCliente3Servlet
 */
@WebServlet("/FormCreaCliente3Servlet")
public class FormCreaCliente3Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FormCreaCliente3Servlet() {
        super();
        // TODO Auto-generated constructor stub
    }


	@SuppressWarnings("unchecked")
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
           throws ServletException, IOException {
		String name = req.getParameter("name");
		String dni = req.getParameter("dni");
		String room = req.getParameter("room");
		
		
		Cliente3 cliente3 = new Cliente3();
		cliente3.setName(name);
		cliente3.setDni(dni);
		cliente3.setRoom(room);
		
		
		Cliente3DAOImplementation.getInstancia().create(cliente3);
		Collection<Cliente3> lp =Cliente3DAOImplementation.getInstancia().readAll();
		req.getSession().setAttribute("clientes3", lp);
		getServletContext().getRequestDispatcher("/Empleados2.jsp").forward(req,resp);
		
 
		
	}
}
