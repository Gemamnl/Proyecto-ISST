package es.upm.dit.isst.concierge.dao;

import java.util.Collection;

import es.upm.dit.isst.concierge.model.Cliente3;

public interface Cliente3DAO {
	public void create(Cliente3 cliente);
	public Cliente3 read(String name);
	public void update(Cliente3 cliente);
	public void delete(Cliente3 cliente);
	public Collection<Cliente3> readAll();
	public Cliente3 login(String dni, String room);
}
