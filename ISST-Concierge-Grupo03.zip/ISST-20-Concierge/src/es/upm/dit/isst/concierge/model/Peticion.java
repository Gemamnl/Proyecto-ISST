package es.upm.dit.isst.concierge.model;
import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Peticion implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Id
	private String id_peticion;

	private int estado;
	private String mensaje;
	
	@ManyToOne 
	private Cliente advisor;
	
	
	public Peticion() {
		super();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id_peticion == null) ? 0 : id_peticion.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Peticion other = (Peticion) obj;
		if (id_peticion == null) {
			if (other.id_peticion != null)
				return false;
		} else if (!id_peticion.equals(other.id_peticion))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Peticion [id_peticion=" + id_peticion + ", estado=" + estado + ", mensaje=" + mensaje + ", advisor="
				+ advisor + "]";
	}



	public String getId_peticion() {
		return id_peticion;
	}

	public void setId_peticion(String id_peticion) {
		this.id_peticion = id_peticion;
	}

	public int getEstado() {
		return estado;
	}

	public void setEstado(int estado) {
		this.estado = estado;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

	public Cliente getAdvisor() {
		return advisor;
	}

	public void setAdvisor(Cliente advisor) {
		this.advisor = advisor;
	}




}
