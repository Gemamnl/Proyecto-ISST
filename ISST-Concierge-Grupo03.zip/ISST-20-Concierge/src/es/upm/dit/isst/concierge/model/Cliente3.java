package es.upm.dit.isst.concierge.model;

import java.io.Serializable;
import java.util.Collection;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Cliente3 implements Serializable {
	
	 private static final long serialVersionUID = 1L;
	
	@Id 
	private String dni;
	public String room; 
	public String name;
	
	@OneToMany(mappedBy = "advisor3", fetch = FetchType.EAGER) 
	private Collection<Peticion3> advisedPeticiones3;
	
	
	public Cliente3() {
		super();
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((dni == null) ? 0 : dni.hashCode());
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Cliente3 other = (Cliente3) obj;
		if (dni == null) {
			if (other.dni != null)
				return false;
		} else if (!dni.equals(other.dni))
			return false;
		return true;
	}


	@Override
	public String toString() {
		return "Cliente3 [dni=" + dni + ", room=" + room + ", name=" + name + ", advisedPeticiones3="
				+ advisedPeticiones3 + "]";
	}


	public String getDni() {
		return dni;
	}


	public void setDni(String dni) {
		this.dni = dni;
	}


	public String getRoom() {
		return room;
	}


	public void setRoom(String room) {
		this.room = room;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public Collection<Peticion3> getAdvisedPeticiones3() {
		return advisedPeticiones3;
	}


	public void setAdvisedPeticiones3(Collection<Peticion3> advisedPeticiones3) {
		this.advisedPeticiones3 = advisedPeticiones3;
	}
	
}
