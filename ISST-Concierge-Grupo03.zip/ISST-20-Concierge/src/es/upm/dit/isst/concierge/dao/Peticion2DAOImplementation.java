package es.upm.dit.isst.concierge.dao;

import java.util.Collection;
import java.util.List;

import org.hibernate.Session;

import es.upm.dit.isst.concierge.model.Peticion2;

public class Peticion2DAOImplementation implements Peticion2DAO {
	private static Peticion2DAOImplementation instancia = null;
	  private Peticion2DAOImplementation() {
	  }

	  public static Peticion2DAOImplementation getInstancia() {
	    if( null == instancia ) 
	      instancia = new Peticion2DAOImplementation();
	    return instancia;
	  }
	  
	  @Override
	  public Peticion2 read(String id_peticion) {
	    Session session = SessionFactoryService.get().openSession();
	    session.beginTransaction();
	    Peticion2 p=session.get(Peticion2.class, id_peticion);
	    session.getTransaction().commit();
	    session.close();
	    return p;
	  }
	  
	  @Override
	  public void create (Peticion2 peticion) {
	    Session session = SessionFactoryService.get().openSession();
	    session.beginTransaction();
	    session.save(peticion);
	    session.getTransaction().commit();
	    session.close();
	  }
	  
	  @Override
	  public void update(Peticion2 peticion) {
	    Session session = SessionFactoryService.get().openSession();
	    session.beginTransaction();
	    session.saveOrUpdate(peticion);
	    session.getTransaction().commit();
	    session.close();
	  }
	  
	  @Override
	  public void delete(Peticion2 peticion) {
	    Session session = SessionFactoryService.get().openSession();
	    session.beginTransaction();
	    session.delete(peticion);
	    session.getTransaction().commit();
	    session.close();
	  }
	  
	  @SuppressWarnings("unchecked")
	  @Override
	  public Collection<Peticion2> readAll() {
	    Session session = SessionFactoryService.get().openSession();
	    session.beginTransaction();
	    List<Peticion2>peticiones=session.createQuery("from Peticion2").list();
	    session.getTransaction().commit();
	    session.close();
	    return peticiones;
	  }


}
