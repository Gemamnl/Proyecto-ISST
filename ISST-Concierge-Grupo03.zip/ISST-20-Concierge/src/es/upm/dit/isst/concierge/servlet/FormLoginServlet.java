package es.upm.dit.isst.concierge.servlet;

import java.io.IOException;
import java.util.Collection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import es.upm.dit.isst.concierge.dao.Cliente2DAOImplementation;
import es.upm.dit.isst.concierge.dao.Cliente3DAOImplementation;
import es.upm.dit.isst.concierge.dao.ClienteDAOImplementation;
import es.upm.dit.isst.concierge.dao.EmpleadoDAOImplementation;
import es.upm.dit.isst.concierge.model.Cliente;
import es.upm.dit.isst.concierge.model.Cliente2;
import es.upm.dit.isst.concierge.model.Cliente3;
import es.upm.dit.isst.concierge.model.Empleado;

/**
 * Servlet implementation class FormLoginServlet
 */
@WebServlet("/FormLoginServlet")
public class FormLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private final String ADMIN_DNI = "DNIadmin";
	//private final String ADMIN_NAME = "admin";
	private final String ADMIN_ROOM = "123";
	
    public FormLoginServlet() {
        super();
    }

    @Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
                           throws ServletException, IOException {
		String dni = req.getParameter("dni");
//		String name = req.getParameter("name");
		String room = req.getParameter("room");
		Collection<Cliente> clientes =  
                         ClienteDAOImplementation.getInstancia().readAll();
		Cliente cliente =ClienteDAOImplementation.getInstancia()
                         .login(dni, room);
		
		Collection<Cliente2> clientes2 =  
                Cliente2DAOImplementation.getInstancia().readAll();
Cliente2 cliente2 =Cliente2DAOImplementation.getInstancia()
                .login(dni, room);

		Collection<Cliente3> clientes3 =  
					Cliente3DAOImplementation.getInstancia().readAll();
Cliente3 cliente3 =Cliente3DAOImplementation.getInstancia()
				.login(dni, room);
		
		
		
		Collection<Empleado> empleados =  
                EmpleadoDAOImplementation.getInstancia().readAll();
Empleado empleado =EmpleadoDAOImplementation.getInstancia()
                .login(dni, room);


		
		
		if( ADMIN_DNI.equals(dni) && ADMIN_ROOM.equals(room) ) {
			req.getSession().setAttribute("admin", true);
			req.getSession().setAttribute("clientes", clientes);
			req.getSession().setAttribute("clientes2", clientes2);
			req.getSession().setAttribute("clientes3", clientes3);
			 req.getSession().setAttribute("empleados", empleados);	
            getServletContext().getRequestDispatcher("/Admin.jsp")
                       .forward(req,resp);

		} else if ( null != cliente) {
			req.getSession().setAttribute("cliente", 
                        ClienteDAOImplementation.getInstancia()
                        .read(cliente.getDni()));
	               getServletContext().getRequestDispatcher("/vip.html")
                      .forward(req,resp);
			
			
		} else if ( null != empleado) {
			
			req.getSession().setAttribute("empleado", 
                        EmpleadoDAOImplementation.getInstancia()
                        .read(empleado.getDni()));
	               getServletContext().getRequestDispatcher("/Empleados2.jsp")
                      .forward(req,resp);
			
		} else if ( null != cliente2) {
			req.getSession().setAttribute("cliente2", 
                    Cliente2DAOImplementation.getInstancia()
                    .read(cliente2.getDni()));
               getServletContext().getRequestDispatcher("/frecuente.html")
                  .forward(req,resp);
               
		} else if ( null != cliente3) {
			req.getSession().setAttribute("cliente3", 
                    Cliente3DAOImplementation.getInstancia()
                    .read(cliente3.getDni()));
               getServletContext().getRequestDispatcher("/estandar.html")
                  .forward(req,resp);
		
		
	} 	else	{
	              getServletContext().getRequestDispatcher("/index.html")
                      .forward(req,resp);
		}
	}

}
