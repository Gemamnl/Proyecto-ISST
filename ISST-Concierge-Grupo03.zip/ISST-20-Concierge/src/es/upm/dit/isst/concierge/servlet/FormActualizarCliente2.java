package es.upm.dit.isst.concierge.servlet;

import java.io.IOException;
import java.util.Collection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import es.upm.dit.isst.concierge.dao.Cliente2DAOImplementation;
import es.upm.dit.isst.concierge.model.Cliente2;

/**
 * Servlet implementation class FormActualizarCliente2
 */
@WebServlet("/FormActualizarCliente2")
public class FormActualizarCliente2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FormActualizarCliente2() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
						
		String name = req.getParameter("name");
		String dni = req.getParameter("dni");
		String room = req.getParameter("room");
		
		
		Cliente2 cliente2 = new Cliente2();
		cliente2.setName(name);
		cliente2.setDni(dni);
		cliente2.setRoom(room);
		
		
		Cliente2DAOImplementation.getInstancia().create(cliente2);
		Collection<Cliente2> lp =Cliente2DAOImplementation.getInstancia().readAll();
		req.getSession().setAttribute("clientes2", lp);
		getServletContext().getRequestDispatcher("/ActualizarPerfil2.jsp").forward(req,resp);
		
		
					
		getServletContext().getRequestDispatcher("/ActualizarPerfil2.jsp").forward(req,resp);
	}

}
