package es.upm.dit.isst.concierge.servlet;


import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;

import es.upm.dit.isst.concierge.dao.ClienteDAOImplementation;
import es.upm.dit.isst.concierge.dao.PeticionDAOImplementation;
import es.upm.dit.isst.concierge.model.Cliente;
import es.upm.dit.isst.concierge.model.Peticion;

@WebServlet("/FormCreaPeticionServlet")
public class FormCreaPeticionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public FormCreaPeticionServlet() {
        super();
    }

    @SuppressWarnings("unchecked")
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
			throws ServletException, IOException {
		String titulo = req.getParameter("titulo");
		String mensaje = req.getParameter("mensaje");
		String dni = req.getParameter("dni");

			Collection<Cliente> clientes = ClienteDAOImplementation.getInstancia().readAll();
			for(Cliente p: clientes) {
				if(p.getDni().contentEquals(dni)) {
					Peticion peticion = new Peticion();
					peticion.setId_peticion(titulo);
					peticion.setMensaje(mensaje);
					peticion.setAdvisor(p);
					peticion.setEstado(1);
					
					JOptionPane.showMessageDialog(null,"Petición pendiente de aceptación");
					
					PeticionDAOImplementation.getInstancia().create(peticion);
					Collection<Peticion> lp= PeticionDAOImplementation.getInstancia().readAll(); 
					req.getSession().setAttribute("peticiones", lp);
					//List<Peticion> pet = new ArrayList<Peticion>();
					//pet.add (peticion);
					//pet.addAll((List<Peticion>) req.getAttribute("peticiones"));
					//req.getSession().setAttribute("peticiones", pet);
					getServletContext().getRequestDispatcher("/vip.html").forward(req,resp);
					
				
					
				}else {
					//JOptionPane.showMessageDialog(null,"dni incorrecto");
					getServletContext().getRequestDispatcher("/FormCrearPeticion.jsp").forward(req,resp);
				}
			}
			


	}


}
