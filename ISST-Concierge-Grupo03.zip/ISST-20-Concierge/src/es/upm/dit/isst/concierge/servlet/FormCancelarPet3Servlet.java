package es.upm.dit.isst.concierge.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;

import es.upm.dit.isst.concierge.dao.Peticion3DAOImplementation;
import es.upm.dit.isst.concierge.model.Peticion3;

/**
 * Servlet implementation class FormCancelarPet3Servlet
 */
@WebServlet("/FormCancelarPet3Servlet")
public class FormCancelarPet3Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FormCancelarPet3Servlet() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Peticion3 pet = Peticion3DAOImplementation.getInstancia().read(req.getParameter("idpeticion"));
		pet.setEstado(3);
		Peticion3DAOImplementation.getInstancia().update(pet);
		JOptionPane.showMessageDialog(null,"Peticion Cancelada");
		req.getSession().setAttribute("peticiones3", Peticion3DAOImplementation.getInstancia().readAll());
		getServletContext().getRequestDispatcher("/Empleados2.jsp").forward(req,resp);
	}

}
