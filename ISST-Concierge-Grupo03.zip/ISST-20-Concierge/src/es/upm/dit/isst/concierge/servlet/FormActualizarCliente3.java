package es.upm.dit.isst.concierge.servlet;

import java.io.IOException;
import java.util.Collection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import es.upm.dit.isst.concierge.dao.Cliente3DAOImplementation;
import es.upm.dit.isst.concierge.model.Cliente3;

/**
 * Servlet implementation class FormActualizarCliente3
 */
@WebServlet("/FormActualizarCliente3")
public class FormActualizarCliente3 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FormActualizarCliente3() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String name = req.getParameter("name");
		String dni = req.getParameter("dni");
		String room = req.getParameter("room");
		
		
		Cliente3 cliente3 = new Cliente3();
		cliente3.setName(name);
		cliente3.setDni(dni);
		cliente3.setRoom(room);
		
		
		Cliente3DAOImplementation.getInstancia().create(cliente3);
		Collection<Cliente3> lp =Cliente3DAOImplementation.getInstancia().readAll();
		req.getSession().setAttribute("clientes3", lp);
		getServletContext().getRequestDispatcher("/ActualizarPerfil3.jsp").forward(req,resp);
		
		
					
		getServletContext().getRequestDispatcher("/ActualizarPerfil3.jsp").forward(req,resp);
	}

}
