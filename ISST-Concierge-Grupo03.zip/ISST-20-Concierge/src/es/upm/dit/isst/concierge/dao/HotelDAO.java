package es.upm.dit.isst.concierge.dao;

import java.util.Collection;
import java.util.List;

import es.upm.dit.isst.concierge.model.Hotel;



public interface HotelDAO {
	public void create(Hotel hotel);
	public Hotel read(String name);
	public void update(Hotel hotel);
	public void delete(Hotel hotel);
	public Collection<Hotel> readAll();
}
