package es.upm.dit.isst.concierge.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import es.upm.dit.isst.concierge.dao.EmpleadoDAOImplementation;
import es.upm.dit.isst.concierge.model.Empleado;

/**
 * Servlet implementation class FormCreaEmpleadoServlet
 */
@WebServlet("/FormCreaEmpleadoServlet")
public class FormCreaEmpleadoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public FormCreaEmpleadoServlet() {
        super();
    }

    @SuppressWarnings("unchecked")
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
           throws ServletException, IOException {
		String name = req.getParameter("name");
		String dni = req.getParameter("dni");
		String room = req.getParameter("room");
		
		
		Empleado empleado = new Empleado();
		empleado.setName(name);
		empleado.setDni(dni);
		empleado.setRoom(room);
		
		
		EmpleadoDAOImplementation.getInstancia().create(empleado);
		List<Empleado> lp = new ArrayList<Empleado>();
		lp.addAll((List<Empleado>)         
                          req.getSession().getAttribute("empleados"));
		lp.add (empleado);
		req.getSession().setAttribute("empleados", lp);
		getServletContext().getRequestDispatcher("/Admin.jsp").forward(req,resp);

}

}
