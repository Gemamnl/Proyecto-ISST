package es.upm.dit.isst.concierge.dao;

import java.util.Collection;
import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;

import es.upm.dit.isst.concierge.model.Cliente2;

public class Cliente2DAOImplementation implements Cliente2DAO {
	private static Cliente2DAOImplementation instancia = null;
	  private Cliente2DAOImplementation() {
	  }

	  public static Cliente2DAOImplementation getInstancia() {
	    if( null == instancia ) 
	      instancia = new Cliente2DAOImplementation();
	    return instancia;
	  }
	  
	  @Override
	  public Cliente2 read (String name) {
	    Session session = SessionFactoryService.get().openSession();
	    session.beginTransaction();
	    Cliente2 p=session.get(Cliente2.class, name);
	    session.getTransaction().commit();
	    session.close();
	    return p;
	  }
	  
	  @Override
	  public void create (Cliente2 cliente) {
	    Session session = SessionFactoryService.get().openSession();
	    session.beginTransaction();
	    session.save(cliente);
	    session.getTransaction().commit();
	    session.close();
	  }
	  
	  @Override
	  public void update(Cliente2 cliente) {
	    Session session = SessionFactoryService.get().openSession();
	    session.beginTransaction();
	    session.update(session);
	    session.getTransaction().commit();
	    session.close();
	  }
	  
	  @Override
	  public void delete(Cliente2 cliente) {
	    Session session = SessionFactoryService.get().openSession();
	    session.beginTransaction();
	    session.delete(cliente);
	    session.getTransaction().commit();
	    session.close();
	  }
	  
	  @SuppressWarnings("unchecked")
	  @Override
	  public Collection<Cliente2>readAll() {
	    Session session = SessionFactoryService.get().openSession();
	    session.beginTransaction();
	    List<Cliente2>clientes2= session.createQuery("from Cliente2").list();
	    session.getTransaction().commit();
	    session.close();
	    return clientes2;
	  }
	  
	  @SuppressWarnings("unchecked")
	  @Override
	  public Cliente2 login(String dni,String room) {
	    Session session = SessionFactoryService.get().openSession();
	    session.beginTransaction();
	    Cliente2 p=null;
	    Query q=session.createQuery("select p from Cliente2 p where p.dni= :dni and p.room= :room");
	    q.setParameter("dni", dni);
	    q.setParameter("room", room);
	    List<Cliente2> profs=q.getResultList();
	    if (profs.size()>0)
	    	p=(Cliente2)(q.getResultList().get(0));
	    session.getTransaction().commit();
	    session.close();
	    return p;
	  }

	  

}

