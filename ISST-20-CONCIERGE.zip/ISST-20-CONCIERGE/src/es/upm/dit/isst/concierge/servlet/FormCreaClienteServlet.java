package es.upm.dit.isst.concierge.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import es.upm.dit.isst.concierge.dao.ClienteDAOImplementation;
import es.upm.dit.isst.concierge.model.Cliente;

/**
 * Servlet implementation class FormCreaProfesorServlet
 */
@WebServlet("/FormCreaClienteServlet")
public class FormCreaClienteServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
       
	
	@SuppressWarnings("unchecked")
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
           throws ServletException, IOException {
		String name = req.getParameter("name");
		String room = req.getParameter("room");
		String tipo = req.getParameter("tipo");
		
		Cliente cliente = new Cliente();
		cliente.setName(name);
		cliente.setRoom(room);
		cliente.setTipo(tipo);
		
		ClienteDAOImplementation.getInstancia().create(cliente);
		List<Cliente> lp = new ArrayList<Cliente>();
		lp.addAll((List<Cliente>)         
                          req.getSession().getAttribute("clientes"));
		lp.add (cliente);
		req.getSession().setAttribute("clientes", lp);
		getServletContext().getRequestDispatcher("/Admin.jsp").forward(req,resp);

}
}
