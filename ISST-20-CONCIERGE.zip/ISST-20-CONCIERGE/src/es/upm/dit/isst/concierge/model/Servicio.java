package es.upm.dit.isst.concierge.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Servicio  implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	private String nombre_servicio;
	private String tipo;
	
	@OneToMany (mappedBy = "advisor2", fetch = FetchType.EAGER)
	private Collection<Peticion> peticiones; 
	
	public Servicio() {
		super();
		this.peticiones= new ArrayList<>();
	}

	@Override
	public String toString() {
		return "Servicio [nombre_servicio=" + nombre_servicio + ", tipo=" + tipo + ", peticiones=" + peticiones + "]";
	}



	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((nombre_servicio == null) ? 0 : nombre_servicio.hashCode());
		result = prime * result + ((peticiones == null) ? 0 : peticiones.hashCode());
		result = prime * result + ((tipo == null) ? 0 : tipo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Servicio other = (Servicio) obj;
		if (nombre_servicio == null) {
			if (other.nombre_servicio != null)
				return false;
		} else if (!nombre_servicio.equals(other.nombre_servicio))
			return false;
		if (peticiones == null) {
			if (other.peticiones != null)
				return false;
		} else if (!peticiones.equals(other.peticiones))
			return false;
		if (tipo == null) {
			if (other.tipo != null)
				return false;
		} else if (!tipo.equals(other.tipo))
			return false;
		return true;
	}

	public String getNombre_servicio() {
		return nombre_servicio;
	}

	public void setNombre_servicio(String nombre_servicio) {
		this.nombre_servicio = nombre_servicio;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public Collection<Peticion> getPeticiones() {
		return peticiones;
	}

	public void setPeticiones(List<Peticion> peticiones) {
		this.peticiones = peticiones;
	}


}
