package es.upm.dit.isst.concierge.servlet;



import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.util.Collection;
import es.upm.dit.isst.concierge.dao.ClienteDAOImplementation;
import es.upm.dit.isst.concierge.model.Cliente;


/**
 * Servlet implementation class FormLoginServlet
 */
@WebServlet("/FormLoginServlet")
public class FormLoginServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	private final String ADMIN_NAME = "admin";
	private final String ADMIN_ROOM = "123";	
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
                           throws ServletException, IOException {
		String name = req.getParameter("name");
		String room = req.getParameter("room");
		Collection<Cliente> clientes =  
                         ClienteDAOImplementation.getInstancia().readAll();
		Cliente cliente =ClienteDAOImplementation.getInstancia()
                         .login(name, room);
		
		
		if( ADMIN_NAME.equals(name) && ADMIN_ROOM.equals(room) ) {
			req.getSession().setAttribute("admin", true);
			req.getSession().setAttribute("clientes", clientes);		     
                      getServletContext().getRequestDispatcher("/Admin.jsp")
                       .forward(req,resp);
		} else if ( null != cliente) {
			
			req.getSession().setAttribute("cliente", 
                        ClienteDAOImplementation.getInstancia()
                        .read(cliente.getName()));
	               getServletContext().getRequestDispatcher("/pag-principal.html")
                      .forward(req,resp);
			
		} else	{
	              getServletContext().getRequestDispatcher("/index.html")
                      .forward(req,resp);
		}
	}
}

