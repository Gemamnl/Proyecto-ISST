package es.upm.dit.isst.concierge.dao;

import java.util.Collection;

import es.upm.dit.isst.concierge.model.Peticion;

public interface PeticionDAO {
	
	public void create(Peticion peticion);
	public Peticion read(String id_peticion);
	public void update(Peticion peticion);
	public void delete(Peticion peticion);
	public Collection<Peticion> readAll();

}
