package es.upm.dit.isst.concierge.model;

import java.io.Serializable;
import java.util.Arrays;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;

@Entity
public class Peticion implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Id
	private String id_peticion;
	
	private int numero_veces;
	private boolean estado_servicio;
	
	@ManyToOne 
	private Cliente advisor;
	
	@ManyToOne 
	private Servicio advisor2;
	
	
	public Peticion() {
		super();
	}


	public Peticion(String id_peticion, int numero_veces, boolean estado_servicio, Cliente advisor,
			Servicio advisor2) {
		super();
		this.id_peticion = id_peticion;
		this.numero_veces = numero_veces;
		this.estado_servicio = estado_servicio;
		this.advisor = advisor;
		this.advisor2 = advisor2;
	}



	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id_peticion == null) ? 0 : id_peticion.hashCode());
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Peticion other = (Peticion) obj;
		if (id_peticion == null) {
			if (other.id_peticion != null)
				return false;
		} else if (!id_peticion.equals(other.id_peticion))
			return false;
		return true;
	}


	public String getId_peticion() {
		return id_peticion;
	}


	public void setId_peticion(String id_peticion) {
		this.id_peticion = id_peticion;
	}


	public int getNumero_veces() {
		return numero_veces;
	}


	public void setNumero_veces(int numero_veces) {
		this.numero_veces = numero_veces;
	}


	public boolean isEstado_servicio() {
		return estado_servicio;
	}


	public void setEstado_servicio(boolean estado_servicio) {
		this.estado_servicio = estado_servicio;
	}


	public Cliente getAdvisor() {
		return advisor;
	}


	public void setAdvisor(Cliente advisor) {
		this.advisor = advisor;
	}


	public Servicio getAdvisor2() {
		return advisor2;
	}


	public void setAdvisor2(Servicio advisor2) {
		this.advisor2 = advisor2;
	}
	
}

	