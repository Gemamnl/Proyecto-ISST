package es.upm.dit.isst.concierge.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import es.upm.dit.isst.concierge.model.Cliente;
import es.upm.dit.isst.concierge.dao.ClienteDAOImplementation;

/**
 * Servlet implementation class FormDatosClienteServlet
 */
@WebServlet("/FormDatosClienteServlet")
public class FormDatosClienteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FormDatosClienteServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		Cliente cliente = ClienteDAOImplementation.getInstancia().read(req.getParameter("name"));
		String name = req.getParameter("name");
		String room = req.getParameter("room");
		String tipo = req.getParameter("tipo");
		
		 getServletContext().getRequestDispatcher("/pag-principal.html")
         .forward(req,resp);
		
	}

	
	
}
