package es.upm.dit.isst.concierge.dao;

import java.util.List;

import es.upm.dit.isst.concierge.model.Servicio;

public interface ServicioDAO {
	public void create(Servicio servicio);
	public Servicio read(String nombre_servicio);
	public void update(Servicio servicio);
	public void delete(Servicio servicio);
	public List<Servicio> readAll();
}
