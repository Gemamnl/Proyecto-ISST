package es.upm.dit.isst.concierge.dao;

import java.util.List;

import org.hibernate.Session;

import es.upm.dit.isst.concierge.model.Servicio;



public class ServicioDAOImplementation implements ServicioDAO {
	private static  ServicioDAOImplementation instancia = null;

	private ServicioDAOImplementation() {
	}

	public static ServicioDAOImplementation getInstancia() {
		if( null == instancia ) 
			instancia = new ServicioDAOImplementation();
		return instancia;
	}
	@Override
	public void create(Servicio servicio) {
		Session session = SessionFactoryService.get().openSession();
		session.beginTransaction();
		session.save(servicio);
		session.getTransaction().commit();
		session.close();
	}

	@Override
	public Servicio read(String nombre_servicio) {
		Session session = SessionFactoryService.get().openSession();
		session.beginTransaction();
		Servicio servicio = session.get(Servicio.class, nombre_servicio);
		session.getTransaction().commit();
		session.close();
		return servicio;
	}

	@Override
	public void update(Servicio servicio) {
		Session session = SessionFactoryService.get().openSession();
		session.beginTransaction();
		session.saveOrUpdate(servicio);
		session.getTransaction().commit();
		session.close();
		
	}

	@Override
	public void delete(Servicio servicio) {
		Session session = SessionFactoryService.get().openSession();
		session.beginTransaction();
		session.delete(servicio);
		session.getTransaction().commit();
		session.close();
		
	}

	@Override
	public List<Servicio> readAll() {
		Session session = SessionFactoryService.get().openSession();
		session.beginTransaction();
		List <Servicio> servicios = session.createQuery("select * from Servicio").list();
		session.getTransaction().commit();
		session.close();
		return servicios;
	}

}
